# The Room Project — Editorial 2

Approved public client-review design, published with GitHub Pages. Includes the graphic cloud hero, shared 3D illustrations, About, How It Works, five packages, Journal and contact-flow preview. Private CMS and SMTP run in the separate PHP/cPanel application.
