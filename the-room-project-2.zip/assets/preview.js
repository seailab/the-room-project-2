"use strict";
document.addEventListener("submit",event=>{
 const form=event.target;if(!form.matches("[data-preview-enquiry]"))return;
 const submit=form.querySelector(".inquiry-submit");if(submit?.hidden)return;
 event.preventDefault();event.stopImmediatePropagation();
 const output=form.querySelector(".inquiry-feedback");output.textContent="This is a website preview. No enquiry was sent or saved. Please contact us directly using the WhatsApp or email links.";output.classList.remove("error");
},true);
