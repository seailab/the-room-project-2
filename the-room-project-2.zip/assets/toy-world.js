/** A single shared GPU renderer paints all visible Editorial pictograms into local 2D slots.
 * Keeps native stacking/clipping, avoids dozens of WebGL contexts, and sleeps offscreen. */
import * as THREE from './vendor/three.module.js';
import {createToyKit,studioLights,stepToy,poseToy} from './toy-models.js';
const settings=window.EDITORIAL||{},reduced=matchMedia('(prefers-reduced-motion: reduce)');
if(settings.sculptedMotifs!==false)startToys();
function startToys(){
 const slots=[...document.querySelectorAll('[data-toy]')].filter(el=>!el.closest('.hero-doodles'));
 if(!slots.length)return;let renderer;try{renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});}catch{return;}
 renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.setClearColor(0,0);renderer.setPixelRatio(1);renderer.setSize(320,320,false);
 const kit=createToyKit(settings),scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-.75,.75,.75,-.75,.1,20);camera.position.z=4;studioLights(scene);
 const objects=new Map(),entries=new Map();let raf=0,last=0,visible=0,time=0,dirty=true,disposed=false,lost=false,frames=0;
 slots.forEach((el,i)=>{const canvas=document.createElement('canvas');canvas.className='toy-canvas';canvas.setAttribute('aria-hidden','true');el.append(canvas);const context=canvas.getContext('2d');if(!context)return;entries.set(el,{el,canvas,context,name:el.dataset.toy,visible:false,hover:0,hoverTo:0,age:0,velocity:0,size:0,index:i});if(!objects.has(el.dataset.toy)){const model=kit.create(el.dataset.toy);scene.add(model);model.visible=false;objects.set(el.dataset.toy,model);}
 const parent=el.closest('a,button,article,.floating-doodle')||el;
 const enter=()=>{if(reduced.matches||settings.pointerMotion===false)return;const entry=entries.get(el);entry.hoverTo=1;entry.age=0;el.dataset.toyHover='true';dirty=true;request();};
 const leave=()=>{const entry=entries.get(el);entry.hoverTo=0;entry.age=0;el.dataset.toyHover='false';dirty=true;request();};
 parent.addEventListener('pointerenter',enter,{passive:true});parent.addEventListener('pointerleave',leave,{passive:true});parent.addEventListener('focusin',enter);parent.addEventListener('focusout',leave);
 });
 function allowed(entry){return (!document.body.classList.contains('menu-open')||!!entry.el.closest('.mobile-menu'))&&entry.visible&&!entry.el.closest('[inert],[hidden]')&&entry.el.getClientRects().length>0;}
 function paint(stamp){
  raf=0;if(disposed||lost||document.hidden)return;
  const dt=last?Math.min((stamp-last)/1000,.08):1/60;last=stamp;time+=dt;
  const moving=!reduced.matches&&settings.floatingMotion;let active=0,interacting=false;
  for(const entry of entries.values()){
   if(!allowed(entry))continue;active++;
   const responding=Math.abs(entry.hover-entry.hoverTo)>.0005||Math.abs(entry.velocity)>.003||entry.hoverTo>0;
   interacting||=responding;
   // Idle decorations update at 10 fps; only the hovered toy uses the full frame rate.
   if(!dirty&&!responding&&stamp-(entry.lastPaint||0)<100)continue;
   const {el,canvas,context}=entry,r=el.getBoundingClientRect();
   const size=Math.min(320,Math.max(48,Math.ceil(Math.max(r.width,r.height)*Math.min(devicePixelRatio||1,1.7))));
   if(size!==entry.size){canvas.width=canvas.height=size;entry.size=size;}
   stepToy(entry,dt);const model=objects.get(entry.name);model.visible=true;
   poseToy(model,entry,time,moving);renderer.render(scene,camera);
   context.clearRect(0,0,size,size);context.drawImage(renderer.domElement,0,0,size,size);model.visible=false;
   el.classList.add('toy-ready');el.dataset.toyState='ready';el.dataset.toyResponse=entry.hover.toFixed(3);entry.lastPaint=stamp;
  }
  dirty=false;frames++;visible=active;document.documentElement.dataset.toyFrames=String(frames);document.documentElement.dataset.toyVisible=String(active);
  document.documentElement.dataset.toyInteracting=String(interacting);
  if(active&&(moving||interacting))raf=requestAnimationFrame(loop);
 }
 let lastPaint=0;
 function loop(stamp){const fast=[...entries.values()].some(e=>allowed(e)&&(e.hoverTo>0||Math.abs(e.hover-e.hoverTo)>.0005||Math.abs(e.velocity)>.003));if(!dirty&&stamp-lastPaint<(fast?15:95)){raf=requestAnimationFrame(loop);return;}lastPaint=stamp;paint(stamp);}
 function request(){if(!raf&&!disposed&&!document.hidden&&!lost)raf=requestAnimationFrame(loop);}
 const observer=new IntersectionObserver(items=>{for(const item of items){const e=entries.get(item.target);e.visible=item.isIntersecting;}dirty=true;request();},{rootMargin:'30px'});entries.forEach(e=>observer.observe(e.el));
 const resizer=new ResizeObserver(()=>{dirty=true;request();});entries.forEach(e=>resizer.observe(e.el));
 const mutation=new MutationObserver(()=>{dirty=true;request();});mutation.observe(document.body,{subtree:true,attributes:true,attributeFilter:['hidden','inert','aria-selected']});
 const menu=new MutationObserver(()=>{dirty=true;request();});menu.observe(document.body,{attributes:true,attributeFilter:['class']});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0;}else{last=0;dirty=true;request();}});reduced.addEventListener('change',()=>{dirty=true;request();});
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;cancelAnimationFrame(raf);raf=0;entries.forEach(e=>e.el.classList.remove('toy-ready'));});renderer.domElement.addEventListener('webglcontextrestored',()=>{lost=false;dirty=true;request();});
 window.addEventListener('pagehide',e=>{cancelAnimationFrame(raf);raf=0;if(e.persisted)return;disposed=true;observer.disconnect();resizer.disconnect();mutation.disconnect();menu.disconnect();kit.dispose();renderer.dispose();});window.addEventListener('pageshow',e=>{if(e.persisted){dirty=true;request();}});request();
}
