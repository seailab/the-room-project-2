import * as THREE from './vendor/three.module.js';
// Shared original miniatures: one material and modelling language across Editorial.
export function createToyKit(settings={}){
 const materials=[],geometries=[];
 const material=(color,roughness=.56,metalness=0)=>{const m=new THREE.MeshStandardMaterial({color,roughness,metalness});materials.push(m);return m};
 const palette={pink:material(settings.pink||'#f7bff1'),lime:material(settings.lime||'#dfff9c'),green:material(settings.green||'#164e43'),blue:material(settings.palette?.sky||'#b9dff0'),yellow:material(settings.palette?.sunshine||'#f4d9af'),lavender:material(settings.palette?.lavender||'#d8ccfb'),coral:material(settings.palette?.coral||'#eaa38c'),wood:material('#c5946b',.75),pearl:material('#eee8d8',.44)};
 const glass=new THREE.MeshPhysicalMaterial({color:'#c7e7e3',transparent:true,opacity:.68,roughness:.15,metalness:.05,clearcoat:.8,side:THREE.DoubleSide});materials.push(glass);
 function mesh(g,m,parent,x=0,y=0,z=0){geometries.push(g);const o=new THREE.Mesh(g,m);o.position.set(x,y,z);parent.add(o);return o;}
 function ell(parent,mat,x,y,z,rx,ry=rx,rz=rx){const o=mesh(new THREE.SphereGeometry(1,24,16),mat,parent,x,y,z);o.scale.set(rx,ry,rz);return o;}
 function tube(parent,mat,points,r=.045){return mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),24,r,8,false),mat,parent);}
 function rounded(parent,mat,w,h,d,r=.05,x=0,y=0,z=0){
  r=Math.min(r,w/2-.001,h/2-.001);const shape=new THREE.Shape(),hw=w/2,hh=h/2;
  shape.moveTo(-hw+r,-hh);shape.lineTo(hw-r,-hh);shape.quadraticCurveTo(hw,-hh,hw,-hh+r);shape.lineTo(hw,hh-r);shape.quadraticCurveTo(hw,hh,hw-r,hh);shape.lineTo(-hw+r,hh);shape.quadraticCurveTo(-hw,hh,-hw,hh-r);shape.lineTo(-hw,-hh+r);shape.quadraticCurveTo(-hw,-hh,-hw+r,-hh);
  const bevel=Math.min(r*.25,d*.18,w*.06,h*.06),geometry=new THREE.ExtrudeGeometry(shape,{depth:d,bevelEnabled:true,bevelSegments:4,steps:1,bevelSize:bevel,bevelThickness:bevel,curveSegments:10});geometry.translate(0,0,-d/2);
  return mesh(geometry,mat,parent,x,y,z);
 }
 function torus(parent,mat,r,tubeR,x=0,y=0,z=0,arc=Math.PI*2){return mesh(new THREE.TorusGeometry(r,tubeR,10,44,arc),mat,parent,x,y,z);}
 function eye(g,x,y,z,s=.035){ell(g,palette.green,x,y,z,s,s*1.25,s*.55);ell(g,palette.pearl,x-s*.25,y+s*.4,z+s*.42,s*.25);}
 function petal(g,mat,angle,length=.44,width=.16,z=0){const p=ell(g,mat,Math.sin(angle)*length*.65,Math.cos(angle)*length*.65,z,width,length*.5,.11);p.rotation.z=-angle;return p;}
 function star(g,color=palette.yellow){const shape=new THREE.Shape();for(let i=0;i<10;i++){const a=i*Math.PI/5+Math.PI/2,r=i%2?.18:.42;const x=Math.cos(a)*r,y=Math.sin(a)*r;i?shape.lineTo(x,y):shape.moveTo(x,y);}shape.closePath();const o=mesh(new THREE.ExtrudeGeometry(shape,{depth:.12,bevelEnabled:true,bevelSize:.055,bevelThickness:.055,bevelSegments:3,curveSegments:10}),color,g);o.position.z=-.06;}
 function build(name){const g=new THREE.Group();g.name=name;
  if(name==='planet'){ell(g,palette.coral,0,0,0,.33);ell(g,palette.yellow,-.11,.12,.27,.07,.06,.025);ell(g,palette.yellow,.1,-.1,.28,.10,.07,.025);const ring=torus(g,palette.lime,.50,.043);ring.rotation.x=1.07;ring.rotation.y=-.25;g.rotation.z=.30;}
  else if(name==='swirl'){const points=[];for(let j=0;j<=72;j++){const a=j/72*Math.PI*4.5,r=.05+j/72*.42;points.push([Math.cos(a)*r,Math.sin(a)*r,j/72*.10]);}tube(g,palette.blue,points,.037);}
  else if(name==='flower'){for(let j=0;j<5;j++)petal(g,palette.pink,j*Math.PI*2/5,.5,.17);ell(g,palette.yellow,0,0,.10,.21,.21,.14);eye(g,-.065,.035,.235,.020);eye(g,.065,.035,.235,.020);tube(g,palette.green,[[-.06,-.065,.23],[0,-.095,.245],[.06,-.065,.23]],.011);}
  else if(name==='sun'){ell(g,palette.yellow,0,0,0,.30,.30,.17);for(let j=0;j<10;j++){const a=j*Math.PI/5;const ray=ell(g,palette.coral,Math.sin(a)*.43,Math.cos(a)*.43,0,.035,.095,.034);ray.rotation.z=-a;}eye(g,-.085,.045,.16,.025);eye(g,.085,.045,.16,.025);ell(g,palette.pink,-.16,-.035,.145,.05,.032,.012);ell(g,palette.pink,.16,-.035,.145,.05,.032,.012);tube(g,palette.green,[[-.07,-.08,.17],[0,-.12,.18],[.07,-.08,.17]],.012);}
  else if(name==='bee'){
   // Four closed, mirrored wing surfaces; each hinge is attached to the thorax.
   const wingMaterial=new THREE.MeshPhysicalMaterial({color:'#e0f3ee',roughness:.35,clearcoat:.5,transparent:true,opacity:.90,depthWrite:false,side:THREE.DoubleSide});materials.push(wingMaterial);
   const wings=[];for(const side of[-1,1])for(const pair of['fore','hind']){
    const hinge=new THREE.Group();hinge.name=`bee-${side<0?'left':'right'}-${pair}wing`;hinge.position.set(.10,.075,-.065);g.add(hinge);
    const fore=pair==='fore',cx=side*(fore?.17:.27),cy=fore?.30:.17,rx=fore?.12:.095,ry=fore?.29:.20,angle=-side*(fore?.45:1.0),cz=fore?-.005:-.08;
    const wing=ell(hinge,wingMaterial,cx,cy,cz,rx,ry,.035);wing.rotation.z=angle;wing.name=hinge.name+'-surface';
    const outline=[];for(let k=0;k<=40;k++){const a=k/40*Math.PI*2,xx=Math.cos(a)*rx,yy=Math.sin(a)*ry;outline.push([cx+xx*Math.cos(angle)-yy*Math.sin(angle),cy+xx*Math.sin(angle)+yy*Math.cos(angle),cz+.02]);}tube(hinge,palette.blue,outline,.007);
    tube(hinge,palette.pearl,[[0,0,cz+.02],[cx*.6,cy*.60,cz+.045],[cx*1.20,cy*1.45,cz+.035]],.006);wings.push(hinge);
   }
   const abdomen=ell(g,palette.yellow,-.10,-.045,0,.31,.205,.18);abdomen.name='bee-abdomen';
   for(const x of[-.27,-.13,.01]){const cross=Math.sqrt(1-Math.pow((x+.10)/.31,2)),stripe=torus(g,palette.green,1,.065,x,-.045,0);stripe.rotation.y=Math.PI/2;stripe.scale.set(.18*cross,.205*cross,.34);}
   ell(g,palette.yellow,.20,-.005,.01,.19,.17,.16).name='bee-thorax';ell(g,palette.yellow,.32,.055,.045,.15,.15,.14);
   eye(g,.28,.095,.171,.024);eye(g,.37,.095,.170,.024);tube(g,palette.green,[[.29,.006,.18],[.33,-.015,.185],[.37,.006,.18]],.009);
   for(const[x,z]of[[.23,-.02],[.37,.055]]){tube(g,palette.green,[[x,.17,z],[x+.015,.30,z],[x+.07,.33,z]],.012);ell(g,palette.green,x+.07,.33,z,.022);}
   for(const side of[-1,1])for(const x of[.06,.15,.24])tube(g,palette.green,[[x,-.08,side*.09],[x-.025,-.27,side*.14],[x+.025,-.29,side*.15]],.012);
   const sting=mesh(new THREE.ConeGeometry(.045,.11,16),palette.green,g,-.43,-.045,0);sting.rotation.z=Math.PI/2;g.userData.wings=wings;
  }
  else if(name==='butterfly'){
   const wings=[];for(const side of[-1,1]){const hinge=new THREE.Group();hinge.name=`butterfly-${side<0?'left':'right'}-wing`;hinge.position.set(side*.025,0,0);g.add(hinge);
    const top=ell(hinge,palette.lavender,side*.21,.14,0,.205,.28,.055);top.rotation.z=-side*.36;
    const lower=ell(hinge,palette.pink,side*.17,-.18,.015,.17,.18,.05);lower.rotation.z=side*.35;
    ell(hinge,palette.blue,side*.26,.18,.054,.10,.15,.018).rotation.z=-side*.30;ell(hinge,palette.yellow,side*.26,.18,.076,.045,.075,.012);ell(hinge,palette.lime,side*.19,-.19,.063,.052,.065,.015);wings.push(hinge);
    tube(g,palette.green,[[side*.02,.23,.08],[side*.065,.34,.08],[side*.12,.36,.09]],.012);ell(g,palette.yellow,side*.12,.36,.09,.021);
   }ell(g,palette.green,0,0,.08,.042,.275,.046);ell(g,palette.green,0,.25,.08,.065,.07,.055);g.userData.wings=wings;
  }
  else if(name==='rainbow'){[palette.coral,palette.yellow,palette.lavender,palette.blue].forEach((mat,i)=>torus(g,mat,.44-i*.085,.043,0,-.15,i*.008,Math.PI));for(const side of[-1,1]){ell(g,palette.pearl,side*.31,-.17,.06,.19,.09,.10);ell(g,palette.pearl,side*.40,-.12,.06,.10,.09,.10);}}
  else if(name==='rocket'){ell(g,palette.pink,0,.07,0,.19,.42,.17);const nose=mesh(new THREE.ConeGeometry(.18,.27,24),palette.coral,g,0,.40,0);rounded(g,palette.blue,.13,.28,.06,.04,-.22,-.17,0).rotation.z=-.4;rounded(g,palette.blue,.13,.28,.06,.04,.22,-.17,0).rotation.z=.4;const rim=torus(g,palette.green,.105,.022,0,.11,.158);ell(g,glass,0,.11,.165,.087,.087,.025);const fire=mesh(new THREE.ConeGeometry(.085,.30,16),palette.yellow,g,0,-.43,0);fire.rotation.z=Math.PI;g.rotation.z=-.28;}
  else if(name==='bed'){
   // Y is up; the mattress, frame and four feet share level datum planes.
   rounded(g,palette.wood,.84,.12,1.12,.055,0,-.025,0).name='bed-frame';
   rounded(g,palette.green,.86,.59,.09,.18,0,.23,-.515).name='bed-headboard';
   rounded(g,palette.wood,.84,.26,.075,.07,0,.02,.52).name='bed-footboard';
   rounded(g,palette.pearl,.77,.14,1.01,.055,0,.105,0).name='bed-mattress';
   rounded(g,palette.blue,.775,.045,.68,.018,0,.195,.155).name='bed-duvet';
   for(let j=-2;j<=2;j++)rounded(g,palette.pearl,.027,.006,.655,.002,j*.13,.221,.155);
   rounded(g,palette.pink,.58,.115,.245,.045,0,.23,-.32).name='bed-pillow';
   for(const x of[-.33,.33])for(const z of[-.43,.43])rounded(g,palette.wood,.07,.22,.07,.015,x,-.185,z).name=`bed-leg-${x<0?'left':'right'}-${z<0?'head':'foot'}`;
  }
  else if(name==='lamp'){
   const inner=material('#e8e5cc',.7);inner.side=THREE.BackSide;
   mesh(new THREE.CylinderGeometry(.18,.32,.42,40,1,true),palette.blue,g,0,.16,0);mesh(new THREE.CylinderGeometry(.171,.31,.416,40,1,true),inner,g,0,.16,0);
   torus(g,palette.green,.32,.010,0,-.05,0).rotation.x=Math.PI/2;torus(g,palette.blue,.18,.009,0,.37,0).rotation.x=Math.PI/2;
   tube(g,palette.wood,[[0,-.05,0],[0,-.26,0],[0,-.40,0]],.025);ell(g,palette.yellow,0,-.43,0,.25,.038,.17);ell(g,palette.yellow,0,.02,0,.07);
  }
  else if(name==='gift'){rounded(g,palette.pink,.56,.44,.39,.055,0,-.03,0);rounded(g,palette.yellow,.61,.11,.43,.035,0,.24,0);rounded(g,palette.blue,.085,.52,.42,.014,0,.01,0);rounded(g,palette.blue,.59,.52,.065,.014,0,.01,0);const bow1=torus(g,palette.blue,.13,.03,-.12,.38,0);bow1.scale.set(1.25,.75,1);bow1.rotation.z=-.5;const bow2=torus(g,palette.blue,.13,.03,.12,.38,0);bow2.scale.set(1.25,.75,1);bow2.rotation.z=.5;g.rotation.y=-.3;}
  else if(name==='heart'){const h=new THREE.Shape();h.moveTo(0,-.31);h.bezierCurveTo(-.7,.12,-.32,.58,0,.24);h.bezierCurveTo(.32,.58,.7,.12,0,-.31);mesh(new THREE.ExtrudeGeometry(h,{depth:.11,bevelEnabled:true,bevelSize:.06,bevelThickness:.06,bevelSegments:4,curveSegments:24}),palette.coral,g,0,0,-.05);}
  else if(name==='crayon'){const body=mesh(new THREE.CylinderGeometry(.09,.09,.65,6),palette.lavender,g,0,0,0);const wood=mesh(new THREE.ConeGeometry(.09,.19,6),palette.wood,g,0,.42,0);mesh(new THREE.ConeGeometry(.034,.08,6),palette.green,g,0,.54,0);rounded(g,palette.yellow,.18,.08,.18,.02,0,-.30,0);g.rotation.z=-.4;}
  else if(name==='dinosaur'){ell(g,palette.pink,-.10,-.13,0,.28,.19,.15);tube(g,palette.pink,[[.05,-.09,0],[.16,.02,0],[.18,.31,0],[.24,.48,0]],.095);ell(g,palette.pink,.28,.48,0,.16,.09,.10);eye(g,.34,.50,.085,.016);for(const z of[-.10,.10])for(const x of[-.25,.03])tube(g,palette.pink,[[x,-.20,z],[x-.02,-.34,z],[x+.07,-.35,z]],.046);tube(g,palette.pink,[[-.3,-.1,0],[-.52,-.17,0],[-.62,-.1,0],[-.63,-.02,0]],.045);for(let i=0;i<5;i++)ell(g,palette.lavender,.09-i*.065,.22-i*.08,-.05,.027,.05,.06);}
  else if(name==='house'){rounded(g,palette.pink,.55,.45,.34,.04,0,-.1,0);const roof=new THREE.Shape();roof.moveTo(-.42,.1);roof.lineTo(0,.48);roof.lineTo(.42,.1);roof.closePath();mesh(new THREE.ExtrudeGeometry(roof,{depth:.47,bevelEnabled:true,bevelSize:.025,bevelThickness:.025,bevelSegments:2}),palette.yellow,g,0,0,-.24);rounded(g,palette.blue,.15,.26,.03,.07,0,-.18,.19);rounded(g,palette.green,.12,.12,.03,.018,-.18,-.04,.19);}
  else if(name==='tree'){tube(g,palette.wood,[[0,-.5,0],[0,-.2,0],[.02,.2,0]],.07);for(const[x,y,s]of[[-.18,.1,.23],[.17,.10,.24],[0,.33,.25],[0,0,.26]])ell(g,palette.lime,x,y,0,s,s,.14);}
  else if(name==='frame'){rounded(g,palette.coral,.53,.68,.07,.04);rounded(g,palette.blue,.41,.56,.025,.02,0,0,.055);const picture=new THREE.Group();g.add(picture);star(picture,palette.yellow);picture.scale.setScalar(.34);picture.position.z=.12;g.scale.multiplyScalar(.8);}
  else if(name==='moon'){const shape=new THREE.Shape();shape.moveTo(.21,.46);shape.bezierCurveTo(-.48,.55,-.62,-.38,.06,-.47);shape.bezierCurveTo(.39,-.53,.56,-.24,.48,-.16);shape.bezierCurveTo(-.09,-.47,-.28,.23,.21,.46);mesh(new THREE.ExtrudeGeometry(shape,{depth:.12,bevelEnabled:true,bevelSize:.05,bevelThickness:.06,bevelSegments:3,curveSegments:24}),palette.yellow,g);eye(g,-.20,.02,.21,.022);}
  else if(name==='palette'){ell(g,palette.wood,0,0,0,.46,.36,.08);for(const[x,y,mat]of[[-.27,.06,palette.pink],[-.14,.23,palette.blue],[.10,.25,palette.lime],[.29,.09,palette.yellow],[.22,-.16,palette.coral]])ell(g,mat,x,y,.09,.074,.074,.025);tube(g,palette.green,[[-.26,-.38,.13],[.16,.10,.15],[.36,.36,.16]],.026);ell(g,palette.blue,.36,.36,.16,.05,.13,.035).rotation.z=-.65;g.rotation.z=-.22;}
  else if(name==='headphones'){torus(g,palette.green,.35,.075,0,0,0,Math.PI);for(const side of[-1,1]){rounded(g,palette.pink,.16,.30,.20,.07,side*.34,-.12,0);rounded(g,palette.yellow,.055,.24,.16,.02,side*.25,-.12,0);}}
  else if(name==='blocks'){for(const[x,y,mat]of[[-.23,-.23,palette.pink],[.23,-.23,palette.blue],[0,.23,palette.yellow]])rounded(g,mat,.42,.42,.36,.06,x,y,0);const mark=new THREE.Group();star(mark,palette.green);mark.scale.setScalar(.26);mark.position.set(0,.23,.22);g.add(mark);g.rotation.y=-.2;}
  else if(name==='wall'){rounded(g,palette.mint||palette.blue,.70,.76,.1,.09);for(const[x,y,mat]of[[-.15,.18,palette.pink],[.18,-.14,palette.yellow],[-.16,-.22,palette.lime]])ell(g,mat,x,y,.08,.10,.10,.04);tube(g,palette.green,[[-.33,.43,.1],[.28,.43,.1],[.28,.27,.1]],.035);}
  else if(name==='fabric'){rounded(g,palette.blue,.66,.72,.07,.05);for(let i=-2;i<=2;i++)tube(g,palette.pearl,[[i*.12,-.34,.08],[i*.12+.035,-.05,.11],[i*.12,.35,.07]],.018);for(let i=-2;i<=2;i++)tube(g,palette.pink,[[-.31,i*.13,.10],[.05,i*.13+.02,.11],[.31,i*.13,.09]],.014);g.rotation.z=-.15;}
  else if(name==='hand'){ell(g,palette.coral,0,-.08,0,.24,.27,.11);for(let i=0;i<4;i++)rounded(g,palette.coral,.10,.38-i*.025,.15,.049,-.17+i*.115,.20-i*.025,0);rounded(g,palette.coral,.11,.30,.15,.05,-.27,-.08,0).rotation.z=-.6;g.rotation.z=-.2;}
  else if(name==='calendar'){rounded(g,palette.pearl,.67,.66,.1,.07);rounded(g,palette.pink,.68,.18,.11,.04,0,.25,.01);for(const x of[-.19,.19])torus(g,palette.green,.055,.022,x,.34,.08).scale.y=1.5;for(let i=0;i<6;i++)ell(g,i===3?palette.coral:palette.blue,-.20+i%3*.20,.07-Math.floor(i/3)*.18,.09,.045,.045,.02);}
  else if(name==='arch'){torus(g,palette.pink,.28,.065,0,.05,0,Math.PI);for(const x of[-.28,.28])tube(g,palette.pink,[[x,.05,0],[x,-.40,0]],.065);torus(g,palette.lime,.14,.04,0,.05,.02,Math.PI);for(const x of[-.14,.14])tube(g,palette.lime,[[x,.05,.02],[x,-.40,.02]],.04);}
  else star(g);
  return g;
 }

 function create(name){
  const sculpt=build(name),box=new THREE.Box3().setFromObject(sculpt),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3()),unit=new THREE.Group();sculpt.position.sub(center);unit.add(sculpt);unit.scale.setScalar(1/Math.max(size.x,size.y,size.z));
  const wrapper=new THREE.Group();wrapper.name=name;wrapper.add(unit);wrapper.userData.sculpt=sculpt;wrapper.userData.wings=sculpt.userData.wings||[];wrapper.userData.pose=toyPose(name);return wrapper;
 }
 return {create,palette,dispose(){materials.forEach(m=>m.dispose());geometries.forEach(g=>g.dispose());}};
}
export function toyPose(name){return name==='bed'?{x:.43,y:-.28,z:0}:name==='bee'?{x:.025,y:-.09,z:-.10}:name==='butterfly'?{x:0,y:0,z:.04}:name==='lamp'?{x:.02,y:-.08,z:0}:{x:.035,y:.10,z:0};}
/** Fast damped response; shared by the hero and every miniature slot. */
export function stepToy(state,dt){
 const h=Math.min(dt,.04);state.velocity??=0;state.age??=0;
 state.velocity+=(state.hoverTo-state.hover)*490*h;state.velocity*=Math.exp(-29*h);state.hover+=state.velocity*h;state.age+=h;
 if(Math.abs(state.hoverTo-state.hover)<.0005&&Math.abs(state.velocity)<.003){state.hover=state.hoverTo;state.velocity=0;}
 return state.hover;
}
export function poseToy(model,state,time,moving=true){
 const h=state.hover,pose=model.userData.pose,name=model.name;
 const play=h*Math.sin(state.age*22)*Math.exp(-state.age*4),flight=['bee','butterfly','rocket'].includes(name);
 const z=name==='flower'?.38:name==='planet'?-.23:name==='bed'?.055:flight?-.20:.14;
 model.rotation.set(pose.x+h*(name==='bed'?-.035:.09)+play*.07,pose.y+h*(name==='planet'?.40:.23),pose.z+h*z+play*.18);
 model.position.set(h*(name==='rocket'?.045:flight?.024:0),h*(flight?.070:.018)+play*.025,0);
 model.scale.setScalar(1+h*.13+play*.035);articulateToy(model,time,h,moving);
}
export function articulateToy(model,time=0,hover=0,moving=true){
 const wings=model.userData.wings||[];for(let i=0;i<wings.length;i++){const side=wings[i].name.includes('left')?-1:1;wings[i].rotation.y=side*(moving?Math.sin(time*(3.5+hover*25))*(.045+hover*.20):0);wings[i].rotation.z=side*hover*.06;}
}
export function studioLights(scene){scene.add(new THREE.HemisphereLight('#fff6e7','#54756c',1.35));const key=new THREE.DirectionalLight('#fff0db',2.5);key.position.set(-3,5,7);scene.add(key);const fill=new THREE.DirectionalLight('#bde6f1',.8);fill.position.set(4,0,5);scene.add(fill);}
