/** Editorial 2: the original graphic cloud, with Editorial 1's sculpted toy constellation. */
import * as THREE from './vendor/three.module.js';
import {createToyKit,studioLights,stepToy,poseToy} from './toy-models.js';
const stage=document.querySelector('[data-cloud]');
if(stage)startHero(stage);
function startHero(stage){
 const settings=window.EDITORIAL||{},host=stage.querySelector('.cloud-webgl'),plate=stage.querySelector('.graphic-cloud-frame'),reduced=matchMedia('(prefers-reduced-motion: reduce)'),abort=new AbortController(),{signal}=abort;
 let width=1,height=1,worldHeight=7.4,aspect=1,renderer,kit,scene,camera,models=[],raf=0,last=0,time=0,elapsed=0,wish=0,inView=true,lost=false,disposed=false,frames=0;
 let ambient=settings.floatingMotion&&!reduced.matches,pointing=settings.pointerMotion&&!reduced.matches;
 const pointer=new THREE.Vector2(),target=new THREE.Vector2(),raycaster=new THREE.Raycaster();
 const layout={sun:[.15,.18,.69,0],planet:[.075,.49,.88,0],rocket:[.16,.34,.61,0],rainbow:[.13,.77,.80,0],butterfly:[.72,.13,.64,1],bee:[.32,.105,.72,1],flower:[.89,.26,.69,1],dinosaur:[.92,.54,.89,1],heart:[.50,.89,.40,2],lamp:[.32,.85,.61,2],bed:[.66,.86,.84,2],gift:[.82,.78,.56,2]};
 const mobile={sun:[.16,.17],planet:[.07,.50],rocket:[.10,.30],rainbow:[.14,.79],butterfly:[.78,.17],bee:[.46,.12],flower:[.92,.36],dinosaur:[.92,.66],heart:[.50,.81],lamp:[.33,.84],bed:[.68,.84],gift:[.87,.81]};
 function fit(){
  const r=host.getBoundingClientRect();if(!r.width||!r.height)return;width=r.width;height=r.height;aspect=width/height;
  // One intrinsic 1200:760 shape. Both constraints choose one uniform scale, never two axes.
  const plateWidth=Math.min(width*(width<700?1:.92),height*.96*(1200/760));
  plate.style.width=plateWidth+'px';const mark=stage.querySelector('.room-logo-hero');
  plate.style.setProperty('--graphic-logo-w',plateWidth*.56+'px');plate.style.setProperty('--graphic-logo-h',plateWidth*(760/1200)*.50+'px');
  if(mark){mark.style.fontSize='100px';const fit=Math.min(plateWidth*.56/mark.offsetWidth,plateWidth*(760/1200)*.50/mark.offsetHeight);mark.style.fontSize=(100*fit*.94).toFixed(2)+'px';}
  stage.dataset.cloudAspect=(1200/760).toFixed(6);stage.dataset.cloudWidth=plateWidth.toFixed(2);
  if(renderer){camera.left=-aspect*worldHeight/2;camera.right=aspect*worldHeight/2;camera.top=worldHeight/2;camera.bottom=-worldHeight/2;camera.updateProjectionMatrix();renderer.setPixelRatio(Math.min(devicePixelRatio||1,2,Math.sqrt(3400000/(width*height))));renderer.setSize(width,height,false);
   models.forEach(g=>{const d=g.userData,a=d.layout,m=width<700?(mobile[g.name]||a):a;d.x=(m[0]-.5)*aspect*worldHeight;d.y=(.5-m[1])*worldHeight;d.size=a[2]*(width<700?.69:1.04);});render(performance.now(),true);request();}
 }
 const active=()=>inView&&!document.hidden&&!document.body.classList.contains('menu-open');
 function render(stamp,once=false){
  if(disposed||lost||!renderer)return;const dt=last?Math.min((stamp-last)/1000,.04):1/60;last=stamp;time+=dt;elapsed+=dt;pointer.lerp(target,1-Math.exp(-18*dt));wish=Math.max(0,wish-dt*1.8);
  models.forEach(g=>{const d=g.userData;stepToy(d,dt);const arrival=reduced.matches?1:THREE.MathUtils.smoothstep((elapsed-.035-d.layout[3]*.035)/.32,0,1),floating=ambient?Math.sin(time*.75+d.phase):0;
   poseToy(g,d,time,ambient);g.position.x+=d.x+pointer.x*.045;g.position.y+=d.y+(1-arrival)*-.12+floating*.026+pointer.y*.025;g.position.z=2;g.scale.multiplyScalar(d.size*(.91+.09*arrival+wish*.025));
   if(g.name===stage.dataset.cloudHover)stage.dataset.cloudHoverResponse=d.hover.toFixed(3);
  });
  renderer.render(scene,camera);stage.dataset.cloudFrame=String(++frames);stage.dataset.cloudEntrance=elapsed>=.58||reduced.matches?'complete':'playing';
  if(once||frames%30===0){camera.updateMatrixWorld();const bounds=models.map(g=>{const box=new THREE.Box3().setFromObject(g),a=box.min.clone().project(camera),b=box.max.clone().project(camera);return{name:g.name,x:Math.round((a.x+1)*width/2),y:Math.round((1-b.y)*height/2),width:Math.round((b.x-a.x)*width/2),height:Math.round((b.y-a.y)*height/2)};});stage.dataset.cloudProps=JSON.stringify(bounds);stage.dataset.cloudClipped=String(bounds.filter(b=>b.x<0||b.y<0||b.x+b.width>width||b.y+b.height>height).length);}
  if(!stage.classList.contains('cloud-webgl-ready')){stage.classList.add('cloud-webgl-ready');stage.dataset.cloudState='ready';stage.dataset.cloudEngine='graphic-svg + three-r'+THREE.REVISION;}
 }
 function animate(stamp){raf=0;if(!active()||disposed||lost)return;if(stamp-last>=15||!last)render(stamp);const moving=ambient||elapsed<.65&&!reduced.matches||pointer.distanceToSquared(target)>.00001||wish>0||models.some(g=>g.userData.hoverTo>0||Math.abs(g.userData.hover-g.userData.hoverTo)>.0005||Math.abs(g.userData.velocity)>.003);stage.dataset.cloudLooping=String(moving);if(moving)raf=requestAnimationFrame(animate);}
 function request(){if(!raf&&active()&&!disposed&&!lost&&renderer)raf=requestAnimationFrame(animate);}
 function visibility(){stage.dataset.cloudActive=String(active());last=0;if(active())request();else{cancelAnimationFrame(raf);raf=0;}}
 fit();
 if(settings.sculptedMotifs!==false){try{
  renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});renderer.setClearColor(0,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.domElement.className='cloud-canvas';renderer.domElement.setAttribute('aria-hidden','true');host.append(renderer.domElement);
  kit=createToyKit(settings);scene=new THREE.Scene();camera=new THREE.OrthographicCamera(-7,7,3.7,-3.7,.1,50);camera.position.z=16;studioLights(scene);
  models=(settings.heroMotifs||Object.keys(layout)).slice(0,12).map((name,i)=>{const g=kit.create(name);Object.assign(g.userData,{layout:layout[name]||layout[Object.keys(layout)[i]],index:i,hover:0,hoverTo:0,age:0,velocity:0,phase:i*1.77});scene.add(g);return g;});
  stage.addEventListener('pointermove',e=>{if(!pointing||e.pointerType==='touch')return;const r=host.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=.5-(e.clientY-r.top)/r.height;target.set(x,y);raycaster.setFromCamera(new THREE.Vector2(x*2,y*2),camera);let hit=raycaster.intersectObjects(models,true)[0]?.object;while(hit&&!models.includes(hit))hit=hit.parent;stage.dataset.cloudHover=hit?.name||'';models.forEach(g=>{const value=g===hit?1:0;if(value!==g.userData.hoverTo)g.userData.age=0;g.userData.hoverTo=value;});request();},{signal,passive:true});
  stage.addEventListener('pointerleave',()=>{target.set(0,0);models.forEach(g=>{g.userData.hoverTo=0;g.userData.age=0;});stage.dataset.cloudHover='';request();},{signal});
  stage.querySelector('.cloud-wish')?.addEventListener('click',()=>{if(!reduced.matches){wish=1;request();}},{signal});
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;cancelAnimationFrame(raf);raf=0;stage.classList.remove('cloud-webgl-ready');stage.dataset.cloudState='fallback';},{signal});renderer.domElement.addEventListener('webglcontextrestored',()=>{lost=false;fit();request();},{signal});
 }catch{renderer?.dispose();renderer=undefined;host.replaceChildren();stage.dataset.cloudState='fallback';}}
 if(!renderer)stage.dataset.cloudState='fallback';
 const resizeObserver=new ResizeObserver(fit);resizeObserver.observe(host);
 const observer=new IntersectionObserver(e=>{inView=e[0].isIntersecting;visibility();},{rootMargin:'40px'});observer.observe(stage);
 const menu=new MutationObserver(visibility);menu.observe(document.body,{attributes:true,attributeFilter:['class']});document.addEventListener('visibilitychange',visibility,{signal});
 reduced.addEventListener('change',()=>{ambient=settings.floatingMotion&&!reduced.matches;pointing=settings.pointerMotion&&!reduced.matches;target.set(0,0);pointer.set(0,0);fit();},{signal});
 document.fonts?.ready.then(()=>{if(!disposed)fit();});
 window.addEventListener('pagehide',e=>{cancelAnimationFrame(raf);raf=0;if(e.persisted)return;disposed=true;abort.abort();resizeObserver.disconnect();observer.disconnect();menu.disconnect();kit?.dispose();renderer?.dispose();},{signal});window.addEventListener('pageshow',e=>{if(e.persisted)visibility();},{signal});fit();request();
}
